﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace gstatus.Models
{
    public class record
    {
        public int id { get; set; }
        public DateTime date { get; set; }
        public string Member_id { get; set; }
        public string Name { get; set; }
        public string code { get; set; }
        public string c_Attributs { get; set; }
        public string user { get; set; }

    }
}