﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace gstatus.Models
{
    public class student_data
    {
        
        public int Id { get; set; }
        public string Member_id { get; set; }
        public string Name { get; set; }
        public string standard { get; set; }
        public string room_cup { get; set; }
        public string A_year { get; set; }
    }
}